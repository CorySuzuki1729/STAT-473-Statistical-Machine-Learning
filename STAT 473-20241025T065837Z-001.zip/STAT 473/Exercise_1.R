## Exercise 1
install.packages("ISLR")
library("ISLR")
sessionInfo()
## The package version is 1.4.
